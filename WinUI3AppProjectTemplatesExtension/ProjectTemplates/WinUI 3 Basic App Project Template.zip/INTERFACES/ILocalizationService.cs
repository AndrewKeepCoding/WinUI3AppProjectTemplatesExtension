using System.Collections.Generic;

namespace $safeprojectname$.Interfaces;

public interface ILocalizationService
{
    IEnumerable<string> AvailableLanguages { get; }

    string LanguageSettingsKey { get; set; }

    string? GetLanguage();

    void SetLanguage(string language);
}