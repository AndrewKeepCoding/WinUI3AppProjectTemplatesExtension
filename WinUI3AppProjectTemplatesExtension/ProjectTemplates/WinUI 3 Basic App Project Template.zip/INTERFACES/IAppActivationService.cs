namespace $safeprojectname$.Interfaces;

public interface IAppActivationService
{
    void Activate(object activationArgs);
}