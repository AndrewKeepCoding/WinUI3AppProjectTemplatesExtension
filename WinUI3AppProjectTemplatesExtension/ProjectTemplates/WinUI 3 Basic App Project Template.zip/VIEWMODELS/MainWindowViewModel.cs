using CommunityToolkit.Mvvm.ComponentModel;

namespace $safeprojectname$.ViewModels;

[ObservableObject]
public partial class MainWindowViewModel
{
}