using Microsoft.UI.Xaml;

namespace $safeprojectname$.ViewModels;

public record ThemeViewModel(ElementTheme Theme, string DisplayName);