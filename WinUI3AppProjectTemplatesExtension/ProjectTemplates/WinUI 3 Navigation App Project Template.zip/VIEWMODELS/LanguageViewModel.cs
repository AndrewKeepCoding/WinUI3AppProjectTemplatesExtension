namespace $safeprojectname$.ViewModels;

public record LanguageViewModel(string Language, string DisplayName);